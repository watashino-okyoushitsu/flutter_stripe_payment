#import <Flutter/Flutter.h>

@interface StripePaymentPlugin : NSObject<FlutterPlugin>

@end
