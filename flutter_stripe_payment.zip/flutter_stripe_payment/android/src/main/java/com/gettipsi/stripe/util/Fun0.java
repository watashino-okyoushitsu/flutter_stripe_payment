package com.gettipsi.stripe.util;

public interface Fun0<R> {
  R call();
}
