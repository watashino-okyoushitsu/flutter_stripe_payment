package com.facebook.react.bridge;

public abstract class BaseActivityEventListener implements ActivityEventListener {

}
