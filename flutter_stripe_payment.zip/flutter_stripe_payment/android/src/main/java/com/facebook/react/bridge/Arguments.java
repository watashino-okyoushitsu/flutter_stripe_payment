package com.facebook.react.bridge;

import java.util.HashMap;
/**
 * Created by FFuF, Jonas Bark on 2019-10-02.
 */
public class Arguments {
    public static WritableMap createMap() {
        return new WritableMap();
    }
}
