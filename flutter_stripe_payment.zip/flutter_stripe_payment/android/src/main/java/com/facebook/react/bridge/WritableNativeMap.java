package com.facebook.react.bridge;

import java.util.HashMap;

/**
 * Created by FFuF, Jonas Bark on 2019-10-02.
 */
public class WritableNativeMap extends WritableMap {

}
