package com.facebook.react.bridge;

public @interface ReactMethod {
}
